			<h3><?php _e('Placeholders', 'easy-watermark'); ?></h3>
				<p class="description"><?php _e('You can use this placeholders in your text watermark, it will be replaced with proper value just befor applying watermark.', 'easy-watermark'); ?></p>
			<table class="widefat"><tbody>
				<tr><td>%image_title%</td><td><?php _e('image title', 'easy-watermark'); ?></td></tr>
				<tr><td>%image_alt%</td><td><?php _e('alternative text for the image', 'easy-watermark'); ?></td></tr>
			</tbody></table>
