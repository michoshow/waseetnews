			<h3><?php _e('Placeholders', 'easy-watermark'); ?></h3>
				<p class="description"><?php _e('You can use this placeholders in your text watermark, it will be replaced with proper value just befor applying watermark.', 'easy-watermark'); ?></p>
			<table class="widefat"><tbody>
				<tr><td>%author%</td><td><?php _e('image author login', 'easy-watermark'); ?></td></tr>
				<tr><td>%author_name%</td><td><?php _e('image author display name', 'easy-watermark'); ?></td></tr>
				<tr><td>%author_email%</td><td><?php _e('image author email address', 'easy-watermark'); ?></td></tr>
				<tr><td>%author_url%</td><td><?php _e('image author url', 'easy-watermark'); ?></td></tr>
			</tbody></table>
