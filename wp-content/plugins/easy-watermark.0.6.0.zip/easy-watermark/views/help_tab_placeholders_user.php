			<h3><?php _e('Placeholders', 'easy-watermark'); ?></h3>
				<p class="description"><?php _e('You can use this placeholders in your text watermark, it will be replaced with proper value just befor applying watermark.', 'easy-watermark'); ?></p>
			<table class="widefat"><tbody>
				<tr><td>%user%</td><td><?php _e('current user login', 'easy-watermark'); ?></td></tr>
				<tr><td>%user_name%</td><td><?php _e('current user display name', 'easy-watermark'); ?></td></tr>
				<tr><td>%user_email%</td><td><?php _e('current user email address', 'easy-watermark'); ?></td></tr>
				<tr><td>%user_url%</td><td><?php _e('current user url', 'easy-watermark'); ?></td></tr>
			</tbody></table>
