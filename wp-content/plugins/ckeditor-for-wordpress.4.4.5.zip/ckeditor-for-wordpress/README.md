CKEditor for WordPress
======================

This plugin replaces the default WordPress editor with [CKEditor](http://ckeditor.com).

## Maintenance status

**Looking for maintainers**. The extension is currently not maintained. Use it at your own risk.

If you would like to take over the development of this extension, then please contact me: w.walc /at/ cksource.com or [@w_walc](https://twitter.com/w_walc). If you are interested in co-maintaining CKEditor for WordPress, then contact me as well or simply send pull requests.

Anyone is welcome to contribute. Without your help the extension will not get any further updates.

## About extension

For information about features, installation, upgrading and changelog check https://wordpress.org/plugins/ckeditor-for-wordpress/

### License

Licensed under the GPL license.

For full details about the license, please check the LICENSE.md file.
