﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ja",{title:"プレースホルダのプロパティ",toolbar:"プレースホルダを作成",name:"プレースホルダ名",invalidName:"プレースホルダは空欄にできません。また、[, ], <, > の文字は使用できません。",pathName:"placeholder"});